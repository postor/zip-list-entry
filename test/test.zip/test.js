var zip2pathobj = require('../index')
var path = require('path')

var file = path.join(__dirname,'test.zip')
console.log(zip2pathobj(file))